package vn.edu.stu.doan_giuaky_android;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TabHost;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.util.FormatUtil;

public class ThuChiActivity extends AppCompatActivity {
    TabHost tabHost;
    EditText etTienChi, etTienThu, etNgayChi, etNgayThu, etMoTaC, etMoTaT;
    Button btnNewDMC, btnNewDMT, btnTaoThu, btnTaoChi;
    Spinner spDMT, spDMC;
    ImageButton datePikerChi, datePikerThu;
    Calendar calendar;
    DBHelper dbHelper;
    int id = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_thu_chi);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getData();
        addControlls();
        addItemDanhMuc();
        addEvents();
    }

    private void getData() {
        Intent intent= getIntent();

        if (intent.hasExtra("ma")){
            id = intent.getIntExtra("ma", 0);
        }
    }

    private void addItemDanhMuc() {
        List<String> itemChi = new ArrayList<>();
        List<String> itemThu = new ArrayList<>();
        Cursor cursorChi = dbHelper.getReadableDatabase().rawQuery("SELECT name FROM Categories WHERE type = ?", new String[]{"1"});
        while (cursorChi.moveToNext()){
            String nameChi = cursorChi.getString(0);
            itemChi.add(nameChi);
        }
        ArrayAdapter<String> adapterChi = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemChi);
        adapterChi.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterChi.notifyDataSetChanged();
        Cursor cursorThu = dbHelper.getReadableDatabase().rawQuery("SELECT name FROM Categories WHERE type = ?", new String[]{"0"});
        while (cursorChi.moveToNext()){
            String nameChi = cursorChi.getString(0);
            itemThu.add(nameChi);
        }
        ArrayAdapter<String> adapterThu = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemThu);
        adapterThu.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterThu.notifyDataSetChanged();
    }

    private void addControlls() {
        dbHelper = new DBHelper(this);
        etTienChi = findViewById(R.id.etTienChi);
        etNgayChi = findViewById(R.id.etNgayChi);
        spDMC = findViewById(R.id.spDanhMucChi);
        datePikerChi = findViewById(R.id.btnDatePikerChi);
        etMoTaC = findViewById(R.id.etMotaC);
        btnNewDMC = findViewById(R.id.btnNewDanhMucChi);
        btnTaoChi = findViewById(R.id.btnThemChi);

        etTienThu = findViewById(R.id.etTienThu);
        etNgayThu = findViewById(R.id.etNgayThu);
        spDMT = findViewById(R.id.spDanhMucThu);
        datePikerThu = findViewById(R.id.btnDatePikerThu);
        etMoTaT = findViewById(R.id.etMotaT);
        btnNewDMT = findViewById(R.id.btnNewDanhMucThu);
        btnTaoThu = findViewById(R.id.btnThemThu);
        calendar = Calendar.getInstance();
        tabHost = findViewById(R.id.tabHost);
        //Xu ly tabHost
        tabHost.setup();
        //Khai báo 2 tab con
        TabHost.TabSpec spec1, spec2;
        //setup 4 công việc cho tabcon
        spec1 = tabHost.newTabSpec("t1");//Tao mới tab
        spec1.setContent(R.id.ChiTieu); // tham chieu id
        spec1.setIndicator("",getResources().getDrawable(R.drawable.pay));
        tabHost.addTab(spec1);// them tab1 vào tab chinh

        spec2 = tabHost.newTabSpec("t2");//Tao mới tab
        spec2.setContent(R.id.ThuNhap); // tham chieu id
        spec2.setIndicator("",getResources().getDrawable(R.drawable.thunhap));
        tabHost.addTab(spec2);// them tab1 vào tab chinh
    }

    private void addEvents() {
        btnNewDMT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(
                        ThuChiActivity.this,
                        AddDanhMucActivity.class
                );
                intent.putExtra("ma", id);
                startActivity(intent);
            }
        });
        btnNewDMC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(
                        ThuChiActivity.this,
                        AddDanhMucActivity.class
                );
                intent.putExtra("ma",id);
                startActivity(intent);
            }
        });
        btnTaoThu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double tien = Double.parseDouble(etTienThu.getText().toString());
                String danhmuc = spDMT.getSelectedItem().toString();
                String ngay = etNgayThu.getText().toString();
                String mota = etMoTaT.getText().toString();
                int category_id = -1;
                Cursor cursorDM = dbHelper.getReadableDatabase().rawQuery("SELECT category_id FROM Categories WHERE name = ? AND type = ? ", new String[]{danhmuc,"0"});
                while (cursorDM.moveToNext()) {
                    category_id = cursorDM.getInt(0);
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put("amount", tien);
                contentValues.put("date", ngay);
                contentValues.put("description", mota);
                contentValues.put("category_id", category_id);
                dbHelper.getWritableDatabase().insert("Transactions",null ,contentValues);
            }
        });
        btnTaoChi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double tien = Double.parseDouble(etTienChi.getText().toString());
                String danhmuc = spDMC.getSelectedItem().toString();
                String ngay = etNgayChi.getText().toString();
                String mota = etMoTaC.getText().toString();
                int category_id = -1;
                Cursor cursorDM = dbHelper.getReadableDatabase().rawQuery("SELECT category_id FROM Categories WHERE name = ? AND type = ?", new String[]{danhmuc,"1"});
                while (cursorDM.moveToNext()) {
                    category_id = cursorDM.getInt(0);
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put("amount", tien);
                contentValues.put("date", ngay);
                contentValues.put("description", mota);
                contentValues.put("category_id", category_id);
                dbHelper.getWritableDatabase().insert("Transactions",null, contentValues);
            }
        });
        datePikerChi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                xuLyChonNgayChi();
            }
        });
        datePikerThu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                xuLyChonNgayThu();
            }
        });
    }
    private void xuLyChonNgayChi(){
        DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DATE, day);
                etNgayChi.setText(FormatUtil.formatDate(calendar.getTime()));
            }
        };
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                ThuChiActivity.this,
                listener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DATE)
        );
        datePickerDialog.show();
    }
    private void xuLyChonNgayThu(){
        DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DATE, day);
                etNgayChi.setText(FormatUtil.formatDate(calendar.getTime()));
            }
        };
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                ThuChiActivity.this,
                listener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DATE)
        );
        datePickerDialog.show();
    }
}