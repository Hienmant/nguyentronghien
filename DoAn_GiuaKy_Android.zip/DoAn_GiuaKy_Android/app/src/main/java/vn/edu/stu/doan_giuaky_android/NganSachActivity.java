package vn.edu.stu.doan_giuaky_android;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.adapter.NganSachAdapter;
import vn.edu.stu.doan_giuaky_android.model.Budget;

public class NganSachActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    int id = -1;
    ListView lvNS;
    ArrayList<Budget> dsNS;
    NganSachAdapter adapter;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ngan_sach);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getData();
        addControlls();
        addEvents();
    }


    private void getData() {
        Intent intent= getIntent();

        if (intent.hasExtra("ma")){
            id = intent.getIntExtra("ma", 0);
        }
    }

    private void addControlls() {
        bottomNavigationView = findViewById(R.id.bottomNavagationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
        lvNS = findViewById(R.id.lvNganSach);
        dsNS = new ArrayList<>();
        dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Budgets WHERE user_id = ? ",new String[]{String.valueOf(id)});
        while (cursor.moveToNext()) {
            int ns_id = cursor.getInt(0);
            int danhmuc_id = cursor.getInt(1);
            double tien = cursor.getDouble(2);
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
            String ngaybd = cursor.getString(3);
            String ngaykt = cursor.getString(4);
            Date ngayStart = null;
            Date ngayEnd = null;
            try {
                // Chuyển đổi chuỗi thành Date
                ngayStart = inputFormat.parse(ngaybd);
                ngayEnd = inputFormat.parse(ngaykt);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            Budget budget = new Budget(ns_id, danhmuc_id, tien, ngayStart, ngayEnd, id);
            dsNS.add(budget);
        }
        adapter = new NganSachAdapter(this, dsNS);
        lvNS.setAdapter(adapter);
    }

    private void addEvents() {
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.bottom_home) {
                    startActivity(new Intent(
                            getApplicationContext(),
                            DashBoardActivity.class
                    ));
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_transaction) {
                    Intent intentGD = new Intent(
                            getApplicationContext(),
                            SoGiaoDichActivity.class
                    );
                    intentGD.putExtra("ma", id);
                    startActivity(intentGD);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_add){
                    Intent intentTC = new Intent(
                            getApplicationContext(),
                            ThuChiActivity.class
                    );
                    intentTC.putExtra("ma", id);
                    startActivity(intentTC);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_budgets){
                    Intent intentNS = new Intent(
                            getApplicationContext(),
                            NganSachActivity.class
                    );
                    intentNS.putExtra("ma", id);
                    startActivity(intentNS);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_category){
                    Intent intentDM = new Intent(
                            getApplicationContext(),
                            CategoryActivity.class
                    );
                    intentDM.putExtra("ma", id);
                    startActivity(intentDM);
                    overridePendingTransition(0, 0);
                }
            }
        });
        lvNS.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                dsNS.remove(position);
                adapter.notifyDataSetChanged();
                return false;
            }
        });
    }
}