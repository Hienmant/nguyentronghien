package vn.edu.stu.doan_giuaky_android.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class DBHelper extends SQLiteOpenHelper {

    private static final String TAG = "DBHelper";
    private static final String DATABASE_NAME = "thuchi.db";
    private static final int DATABASE_VERSION = 1;

    private final Context context;
    private static String DATABASE_PATH = "";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;

        // Đường dẫn lưu trữ cơ sở dữ liệu
        DATABASE_PATH = context.getApplicationInfo().dataDir + "/databases/";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Không cần xử lý tạo bảng vì sử dụng cơ sở dữ liệu có sẵn
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);
        context.deleteDatabase(DATABASE_NAME); // Xóa cơ sở dữ liệu cũ
        try {
            copyDatabase();
        } catch (Exception e) {
            Log.e(TAG, "Error upgrading database: " + e.getMessage());
        }
    }

    // Phương thức kiểm tra xem cơ sở dữ liệu đã tồn tại hay chưa
    private boolean checkDatabase() {
        File dbFile = new File(DATABASE_PATH + DATABASE_NAME);
        return dbFile.exists();
    }

    // Phương thức sao chép cơ sở dữ liệu từ thư mục assets
    private void copyDatabase() {
        try {
            InputStream input = context.getAssets().open(DATABASE_NAME);
            File databaseFolder = new File(DATABASE_PATH);

            // Tạo thư mục nếu chưa tồn tại
            if (!databaseFolder.exists()) {
                databaseFolder.mkdirs();
            }

            String outFileName = DATABASE_PATH + DATABASE_NAME;
            OutputStream output = new FileOutputStream(outFileName);

            // Sao chép dữ liệu
            byte[] buffer = new byte[1024];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }

            // Đóng luồng
            output.flush();
            output.close();
            input.close();

            Log.d(TAG, "Database copied successfully.");
        } catch (Exception e) {
            Log.e(TAG, "Error copying database: " + e.getMessage());
        }
    }

    // Phương thức mở cơ sở dữ liệu
    public SQLiteDatabase openDatabase() {
        String dbPath = DATABASE_PATH + DATABASE_NAME;
        return SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    @Override
    public synchronized void close() {
        super.close();
    }
}
