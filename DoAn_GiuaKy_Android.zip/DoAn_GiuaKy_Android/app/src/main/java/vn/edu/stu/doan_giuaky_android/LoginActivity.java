package vn.edu.stu.doan_giuaky_android;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;

public class LoginActivity extends AppCompatActivity {
    DBHelper dbHelper;
    EditText etUserName, etPass;
    Button btnLogin;
    TextView tvRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        addControlls();
        addEvents();
    }



    private void addControlls() {
        dbHelper = new DBHelper(this);
        etUserName = findViewById(R.id.etUserName);
        etPass = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tv_registernow);
    }

    private void addEvents() {
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(
                        LoginActivity.this,
                        RegisterActivity.class
                );
                startActivity(intent);
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String acc = etUserName.getText().toString();
                String pass = etPass.getText().toString();
                if (acc.isEmpty() || pass.isEmpty()){
                    Toast.makeText(LoginActivity.this,
                            "Vui lòng điền thông tin!",
                            Toast.LENGTH_LONG).show();
                }else {
                    onLogin(acc, hashPassword(pass));
                }
            }
        });
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString(); // Trả về mật khẩu đã mã hóa
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }



    private void onLogin(String username, String password) {
        int user_id = -1;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        //doan rawquery dau e sua lai thay noi//thêm lauị đi
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE username = ? AND password_hash = ?",new String[]{username,password});
        boolean exist = cursor.moveToFirst();
        user_id=cursor.getInt(0);
        if (exist) {
            updateUserLogin(user_id);
            Intent intent = new Intent(
                    LoginActivity.this,
                    DashBoardActivity.class
            );
            intent.putExtra("ma",user_id);
            startActivity(intent);
            Toast.makeText(this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
            db.close();
        } else {
            Toast.makeText(this, "Sai tên đăng nhập hoặc mật khẩu.", Toast.LENGTH_SHORT).show();
        }
    }
    public void updateUserLogin(Integer id){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues updateUser = new ContentValues();
        LocalDate currentDate = LocalDate.now();
        String ngaylogin = currentDate.toString();
        updateUser.put("last_login", ngaylogin);
        db.update("USERS", updateUser, "user_id = ?", new String[]{String.valueOf(id)});  // Thực hiện cập nhật
        db.close();
    }
}