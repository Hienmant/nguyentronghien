package vn.edu.stu.doan_giuaky_android.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import vn.edu.stu.doan_giuaky_android.R;
import vn.edu.stu.doan_giuaky_android.model.Category;

public class CategoryChiAdapter extends BaseAdapter {
    Activity context;
    ArrayList<Category> lLoai;

    public CategoryChiAdapter(Activity context, ArrayList<Category> lLoai) {
        this.lLoai = lLoai;
        this.context = context;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.item_dm_chitieu, null);

        TextView ten = row.findViewById(R.id.tvTenDMChi);

        Category category = lLoai.get(i);
        ten.setText(category.toString());
        return row;
    }




}
