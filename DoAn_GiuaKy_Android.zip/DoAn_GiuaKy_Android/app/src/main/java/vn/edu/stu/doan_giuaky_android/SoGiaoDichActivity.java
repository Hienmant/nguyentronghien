package vn.edu.stu.doan_giuaky_android;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Calendar;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.util.FormatUtil;

public class SoGiaoDichActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    Spinner spChon;
    ImageButton ngayThangNam;
    TextView tvHienThi;
    ArrayAdapter<String> adapter;
    ArrayList<String> itemSp;
    ListView lvGD;
    Calendar calendar;
    DBHelper dbHelper;
    int id = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_so_giao_dich);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addControlls();
        getData();
        addEvents();
    }

    private void getData() {
        Intent intent= getIntent();

        if (intent.hasExtra("ma")){
            id = intent.getIntExtra("ma", 0);
        }
    }

    private void addControlls() {
        dbHelper = new DBHelper(this);
        bottomNavigationView = findViewById(R.id.bottomNavagationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
        spChon = findViewById(R.id.spLocTT);
        ngayThangNam = findViewById(R.id.btnDayPicker);
        tvHienThi = findViewById(R.id.tvTime);
        itemSp= new ArrayList<>();
        itemSp.add("Ngày");
        itemSp.add("Tháng");
        itemSp.add("Năm");
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemSp);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spChon.setAdapter(adapter);
    }

    private void addEvents() {
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.bottom_home) {
                    startActivity(new Intent(
                            getApplicationContext(),
                            DashBoardActivity.class
                    ));
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_transaction) {
                    Intent intentGD = new Intent(
                            getApplicationContext(),
                            SoGiaoDichActivity.class
                    );
                    intentGD.putExtra("ma", id);
                    startActivity(intentGD);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_add){
                    Intent intentTC = new Intent(
                            getApplicationContext(),
                            ThuChiActivity.class
                    );
                    intentTC.putExtra("ma", id);
                    startActivity(intentTC);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_budgets){
                    Intent intentNS = new Intent(
                            getApplicationContext(),
                            NganSachActivity.class
                    );
                    intentNS.putExtra("ma", id);
                    startActivity(intentNS);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_category){
                    Intent intentDM = new Intent(
                            getApplicationContext(),
                            CategoryActivity.class
                    );
                    intentDM.putExtra("ma", id);
                    startActivity(intentDM);
                    overridePendingTransition(0, 0);
                }
            }
        });
        ngayThangNam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (spChon.getSelectedItem().toString().equals("Ngày")){
                    xuLyChonNgay();
                } else if (spChon.getSelectedItem().toString().equals("Tháng")) {
                    xuLyChonThang();
                }else {
                    xuLyChonNam();
                }
            }
        });

    }

    private void xuLyChonNgay(){
        calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DATE, day);
                tvHienThi.setText(FormatUtil.formatDate(calendar.getTime()));
            }
        };
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                SoGiaoDichActivity.this,
                listener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DATE)
        );
        datePickerDialog.show();
    }

    private void xuLyChonThang() {
        // Khởi tạo Calendar
        calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                SoGiaoDichActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // Chỉ cần cập nhật tháng và năm
                        calendar.set(Calendar.YEAR, selectedYear);
                        calendar.set(Calendar.MONTH, selectedMonth);
                        // Hiển thị tháng và năm đã chọn
                        tvHienThi.setText((selectedMonth + 1) + "/" + selectedYear); // +1 vì tháng bắt đầu từ 0
                    }
                },
                year,
                month,
                1 // Chọn ngày mặc định là 1
        ) {
            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                // Ẩn phần chọn ngày
                DatePicker datePicker = getDatePicker();
                datePicker.setCalendarViewShown(false); // Ẩn CalendarView
                datePicker.setSpinnersShown(true); // Hiển thị Spinner cho tháng và năm
            }
        };
        datePickerDialog.show();
    }
    private void xuLyChonNam() {
        // Khởi tạo Calendar
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH); // Mặc định không cần sử dụng
        int day = calendar.get(Calendar.DAY_OF_MONTH); // Mặc định không cần sử dụng

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                SoGiaoDichActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        // Chỉ cần cập nhật năm
                        calendar.set(Calendar.YEAR, selectedYear);
                        // Hiển thị năm đã chọn
                        tvHienThi.setText(String.valueOf(selectedYear));
                    }
                },
                year,
                month,
                day // Chọn ngày mặc định là ngày hiện tại
        ) {
            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                // Ẩn phần chọn tháng và ngày
                DatePicker datePicker = getDatePicker();
                datePicker.setCalendarViewShown(false); // Ẩn CalendarView
                datePicker.setSpinnersShown(true); // Hiển thị Spinner cho năm
                datePicker.setMinDate(System.currentTimeMillis() - 1000); // Đảm bảo không chọn ngày quá khứ
            }
        };

        // Hiển thị dialog
        datePickerDialog.show();
    }

    private void loadALLGiaoDich(){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT description, amount, c.name FROM Transactions t JOIN Categories c ON t.category_id = t.category_id WHERE user_id = ?",new String[]{String.valueOf(id)});

    }
}