package vn.edu.stu.doan_giuaky_android;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.model.Category;

public class AddDanhMucActivity extends AppCompatActivity {
    EditText etTenDM;
    Spinner spLoaiDM;
    Button btnDM;
    int id = -1;
    List<String> ds;
    ArrayAdapter<String> adapter;
    DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_danh_muc);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getData();
        addControlls();
        addEvents();
    }

    private void getData() {
        Intent intent= getIntent();
        if (intent.hasExtra("ma")){
            id = intent.getIntExtra("ma", 0);
        }
    }
    private void addControlls() {
        dbHelper = new DBHelper(this);
        etTenDM = findViewById(R.id.etTenDM);
        btnDM = findViewById(R.id.btnTaoDM);
        spLoaiDM = findViewById(R.id.spLoaiDM);
        ds = new ArrayList<>();
        ds.add("Thu Nhập");
        ds.add("Chi Tiêu");
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ds);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spLoaiDM.setAdapter(adapter);
    }

    private void addEvents() {
        btnDM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameDM = etTenDM.getText().toString();
                boolean t = false;
                if (spLoaiDM.getSelectedItem().toString().equals("Chi Tiêu")){
                    t = true;
                }else if (spLoaiDM.getSelectedItem().toString().equals("Thu Nhập")){
                    t = false;
                }else {
                    Toast.makeText(AddDanhMucActivity.this,"Lỗi !",Toast.LENGTH_LONG);
                }
                Category category = new Category(nameDM, t, id);
                if (addCategory(category)){
                    Toast.makeText(getApplicationContext(), " Tạo thành công", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(
                            AddDanhMucActivity.this,
                            CategoryActivity.class
                    );
                    intent.putExtra("ma", id);
                    startActivity(intent);
                }else {
                    Toast.makeText(getApplicationContext(), " Tạo thất bại!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public boolean addCategory(Category category) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", category.getName());
        int t = -1;
        if (category.isType())
            t = 1;
        else
            t = 0;
        contentValues.put("type", t);
        contentValues.put("user_id", id);
        long result = db.insert("Categories",null, contentValues);
        dbHelper.close();
        return result != -1; // Trả về true nếu thêm thành công, ngược lại là false
    }
}