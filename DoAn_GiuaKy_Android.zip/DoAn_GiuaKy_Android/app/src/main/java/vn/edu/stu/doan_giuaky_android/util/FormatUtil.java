package vn.edu.stu.doan_giuaky_android.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FormatUtil {
    static SimpleDateFormat sdfDateTime =
            new SimpleDateFormat("dd/MM/yyyy hh:mm aa");
    static SimpleDateFormat sdfDate =
            new SimpleDateFormat("dd/MM/yyyy");
    static SimpleDateFormat sdfDayMonth =
            new SimpleDateFormat("dd/MM");
    static SimpleDateFormat sdfYear =
            new SimpleDateFormat("yyyy");

    public static String formatDateTime(Date date) {
        return sdfDateTime.format(date);
    }
    public static String formatDate(Date date) {
        return sdfDate.format(date);
    }
    public static String formatDayMonth(Date date) {
        return sdfDayMonth.format(date);
    }
    public static String formatYear(Date date) {
        return sdfYear.format(date);
    }
}
