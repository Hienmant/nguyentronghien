package vn.edu.stu.doan_giuaky_android;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.security.auth.Subject;

public class DashBoardActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    BarChart barChart;
    ArrayList<BarEntry> entries;
    int id= -1;

    private List<String> xValues = Arrays.asList("Ăn uống","Mua sắm","Lương thưởng","Gà nướng","Sinh nhật");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dash_board);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getData();
        addControlls();
        addEvents();
    }

    private void getData() {
        Intent intent= getIntent();

        if (intent.hasExtra("ma")){
            id = intent.getIntExtra("ma", 0);
        }
    }

    private void addControlls() {
        bottomNavigationView = findViewById(R.id.bottomNavagationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
        barChart = findViewById(R.id.chart);
        barChart.getAxisRight().setDrawLabels(false);

        entries = new ArrayList<>();
        entries.add(new BarEntry(0, 45f));
        entries.add(new BarEntry(1, 80f));
        entries.add(new BarEntry(2, 65f));
        entries.add(new BarEntry(3, 35f));
        entries.add(new BarEntry(4, 55f));
        entries.add(new BarEntry(5, 25f));

        YAxis yAxis = barChart.getAxisLeft();
        yAxis.setAxisMaximum(0f);
        yAxis.setAxisMaximum(100f);
        yAxis.setAxisLineWidth(2f);
        yAxis.setAxisLineColor(Color.BLACK);
        yAxis.setLabelCount(10);

        BarDataSet dataSet = new BarDataSet(entries, "Subjects");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);

        BarData barData = new BarData(dataSet);
        barChart.setData(barData);

        barChart.getDescription().setEnabled(false);
        barChart.invalidate();

        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(xValues));
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getXAxis().setGranularity(1f);
        barChart.getXAxis().setGranularityEnabled(true);

    }

    private void addEvents() {
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.bottom_home) {
                    startActivity(new Intent(
                            getApplicationContext(),
                            DashBoardActivity.class
                    ));
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_transaction) {
                    Intent intentGD = new Intent(
                            getApplicationContext(),
                            SoGiaoDichActivity.class
                    );
                    intentGD.putExtra("ma", id);
                    startActivity(intentGD);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_add){
                    Intent intentTC = new Intent(
                            getApplicationContext(),
                            ThuChiActivity.class
                    );
                    intentTC.putExtra("ma", id);
                    startActivity(intentTC);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_budgets){
                    Intent intentNS = new Intent(
                            getApplicationContext(),
                            NganSachActivity.class
                    );
                    intentNS.putExtra("ma", id);
                    startActivity(intentNS);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_category){
                    Intent intentDM = new Intent(
                            getApplicationContext(),
                            CategoryActivity.class
                    );
                    intentDM.putExtra("ma", id);
                    startActivity(intentDM);
                    overridePendingTransition(0, 0);
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option_tt, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.about) {
            Intent intent = new Intent(
                    DashBoardActivity.this,
                    AboutActivity.class);
            startActivity(intent);
        }
        if (item.getItemId() == R.id.exit){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}