package vn.edu.stu.doan_giuaky_android.model;

import java.io.Serializable;
import java.sql.Date;

public class Transaction implements Serializable {
    private int transaction_id;
    private double amount;
    private Date date;
    private String description;
    private int category_id;
    private int user_id;

    public Transaction(int transaction_id, Date date, double amount, String description, int category_id, int user_id) {
        this.transaction_id = transaction_id;
        this.date = date;
        this.amount = amount;
        this.description = description;
        this.category_id = category_id;
        this.user_id = user_id;
    }

    public int getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(int transaction_id) {
        this.transaction_id = transaction_id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
}
