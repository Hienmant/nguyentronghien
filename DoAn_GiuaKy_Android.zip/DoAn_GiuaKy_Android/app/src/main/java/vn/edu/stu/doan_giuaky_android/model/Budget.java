package vn.edu.stu.doan_giuaky_android.model;

import java.io.Serializable;
import java.util.Date;

public class Budget implements Serializable {
    private int budget_id;
    private int category_id;
    private double amount;
    private Date start_date;
    private Date end_date;
    private int user_id;

    public Budget(int budget_id, int category_id, double amount, Date start_date, Date end_date, int user_id) {
        this.budget_id = budget_id;
        this.category_id = category_id;
        this.amount = amount;
        this.start_date = start_date;
        this.end_date = end_date;
        this.user_id = user_id;
    }

    public int getBudget_id() {
        return budget_id;
    }

    public void setBudget_id(int budget_id) {
        this.budget_id = budget_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getStart_date() {
        return start_date;
    }

    public void setStart_date(Date start_date) {
        this.start_date = start_date;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    @Override
    public String toString() {
        return ""+ amount+ start_date + end_date;
    }
}
