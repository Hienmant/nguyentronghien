package vn.edu.stu.doan_giuaky_android;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.Calendar;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.util.DBConfigUtil;

public class RegisterActivity extends AppCompatActivity {

    EditText etUserName, etPass, etEmail;
    Button btnRegister;
    Calendar calendar;
    DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addControlls();
        addEvents();
    }

    private void addControlls() {
        dbHelper = new DBHelper(this);
        etUserName = findViewById(R.id.etUserName);
        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
        calendar = Calendar.getInstance();
    }

    private void addEvents() {
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etUserName.getText().toString().trim();
                String email = etEmail.getText().toString().trim();
                String password = etPass.getText().toString().trim();
                LocalDate currentDate = LocalDate.now();
                String ngaytao = currentDate.toString();
                String ngaylogin = currentDate.toString();
                String mahoapass = hashPassword(password);

                // Kiểm tra nếu các trường còn trống
                if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Vui lòng điền đầy đủ thông tin.", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put("username", name);
                    values.put("email", email);
                    values.put("password_hash", mahoapass);
                    values.put("created_at", ngaytao); // Thêm ngày tạo vào
                    values.put("last_login", ngaylogin); // Thêm ngày đăng nhập vào

                    long cursor = db.insert("Users", null, values);
                    if (cursor != -1) {
                        Toast.makeText(RegisterActivity.this, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish(); // Đóng RegisterActivity sau khi chuyển sang LoginActivity
                    } else {
                        Toast.makeText(RegisterActivity.this, "Đăng ký thất bại. Vui lòng thử lại.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(RegisterActivity.this, "Lỗi khi lưu dữ liệu: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private String hashPassword(String password)
    {
        try
        {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash)
            {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString(); // Trả về mật khẩu đã mã hóa
        } catch (NoSuchAlgorithmException e)
        {
            throw new RuntimeException(e);
        }
    }
//    private boolean checkUser(String name){
//        Cursor cursor = dbHelper.getReadableDatabase().query("Users", null,
//                "username = ?", new String[]{name}, null, null, null);
//        boolean exists = cursor != null && cursor.getCount() > 0;
//        if (cursor != null) {
//            cursor.close();
//        }
//        return exists; // Trả về true nếu tên người dùng đã tồn tại
//    }
}