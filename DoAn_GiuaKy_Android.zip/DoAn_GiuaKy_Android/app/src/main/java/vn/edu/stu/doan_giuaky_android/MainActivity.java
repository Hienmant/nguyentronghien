package vn.edu.stu.doan_giuaky_android;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import vn.edu.stu.doan_giuaky_android.util.DBConfigUtil;

public class MainActivity extends AppCompatActivity {
    TextView marqueeText;
    Button btnQL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initDB();

        //DBConfigUtil.copyDatabaseFromAssets(MainActivity.this);
        marqueeText = findViewById(R.id.marquee_text);
        btnQL = findViewById(R.id.btnQL);
        // Bắt đầu animation
        startMarqueeAnimation();
        addEvents();
    }

    private void initDB() {
        DBConfigUtil.copyDatabaseFromAssets(MainActivity.this);
    }

    private void addEvents() {
        btnQL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(
                        MainActivity.this,
                        LoginActivity.class
                );
                startActivity(intent);
            }
        });
    }

    private void startMarqueeAnimation() {
        // Lấy chiều rộng của màn hình
        int screenWidth = getResources().getDisplayMetrics().widthPixels;

        // Lấy chiều rộng của TextView
        marqueeText.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int textWidth = marqueeText.getMeasuredWidth();

        // Thiết lập animation
        ObjectAnimator animator = ObjectAnimator.ofFloat(marqueeText, "translationX", screenWidth, -textWidth);
        animator.setDuration(9000); // Thời gian chạy animation (5 giây)
        animator.setRepeatCount(ObjectAnimator.INFINITE); // Lặp lại vô hạn
        animator.setRepeatMode(ObjectAnimator.RESTART); // Khởi động lại animation
        animator.start();
    }
}