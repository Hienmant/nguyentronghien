package vn.edu.stu.doan_giuaky_android;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.adapter.CategoryChiAdapter;
import vn.edu.stu.doan_giuaky_android.adapter.CategoryThuAdapter;
import vn.edu.stu.doan_giuaky_android.model.Category;

public class CategoryActivity extends AppCompatActivity {
    DBHelper dbHelper ;
    BottomNavigationView bottomNavigationView;
    ListView lThu, lChi;
    Button btnAdd;
    CategoryChiAdapter adapterChi;
    CategoryThuAdapter adapterThu;
    ArrayList<Category> dsDMChi, dsDMThu;
    int id = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_category);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getData();
        loadData();
        addControlls();
        addEvents();
    }

    private void loadData() {

    }

    private void getData() {
        Intent intent= getIntent();
        if (intent.hasExtra("ma")){
            id = intent.getIntExtra("ma", 0);
        }
    }

    private void addControlls() {
        dbHelper = new DBHelper(this);
        bottomNavigationView = findViewById(R.id.bottomNavagationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
        btnAdd = findViewById(R.id.btnAdd);
        lChi = findViewById(R.id.lDMChiTieu);
        lThu = findViewById(R.id.lDMThuNhap);

        dsDMChi = new ArrayList<>();
        dsDMThu = new ArrayList<>();
        for (Category category: getAll(id)){
            if (category.isType() == true)
                dsDMChi.add(category);
            else
                dsDMThu.add(category);
        }

        adapterChi = new CategoryChiAdapter(this, dsDMChi);
        adapterThu = new CategoryThuAdapter(this, dsDMThu);
        lChi.setAdapter(adapterChi);
        lThu.setAdapter(adapterThu);
    }

    private void addEvents() {
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.bottom_home) {
                    startActivity(new Intent(
                            getApplicationContext(),
                            DashBoardActivity.class
                    ));
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_transaction) {
                    Intent intentGD = new Intent(
                            getApplicationContext(),
                            SoGiaoDichActivity.class
                    );
                    intentGD.putExtra("ma", id);
                    startActivity(intentGD);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_add){
                    Intent intentTC = new Intent(
                            getApplicationContext(),
                            ThuChiActivity.class
                    );
                    intentTC.putExtra("ma", id);
                    startActivity(intentTC);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_budgets){
                    Intent intentNS = new Intent(
                            getApplicationContext(),
                            NganSachActivity.class
                    );
                    intentNS.putExtra("ma", id);
                    startActivity(intentNS);
                    overridePendingTransition(0, 0);
                }
                if (id == R.id.bottom_category){
                    Intent intentDM = new Intent(
                            getApplicationContext(),
                            CategoryActivity.class
                    );
                    intentDM.putExtra("ma", id);
                    startActivity(intentDM);
                    overridePendingTransition(0, 0);
                }
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(
                        CategoryActivity.this,
                        AddDanhMucActivity.class);
                intent.putExtra("ma", id);
                startActivity(intent);
            }
        });
        lChi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder =new AlertDialog.Builder(CategoryActivity.this);
                builder.setIcon(android.R.drawable.ic_delete);
                builder.setTitle("Xóa danh mục !");
                builder.setMessage("Bạn chắc chắn muốn xóa ?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Category category = dsDMChi.get(position);
                        deleteCategoryWithCheck(category);
                    }
                });
                builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                return true;
            }
        });
        lThu.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder =new AlertDialog.Builder(CategoryActivity.this);
                builder.setIcon(android.R.drawable.ic_delete);
                builder.setTitle("Xóa danh mục !");
                builder.setMessage("Bạn chắc chắn muốn xóa ?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Category category = dsDMThu.get(position);
                        deleteCategoryWithCheck(category);
                    }
                });
                builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                return true;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.home) {
            Intent intent = new Intent(
                    CategoryActivity.this,
                    DashBoardActivity.class);
            intent.putExtra("ma", id);
            startActivity(intent);
        }
        if (item.getItemId() == R.id.exit){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void deleteCategoryWithCheck(Category category) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        SQLiteDatabase database = dbHelper.getReadableDatabase();
        // Kiểm tra xem categoryId có trong Budgets không
        Cursor cursor = database.rawQuery(
                "SELECT * FROM Budgets WHERE category_id = ? AND user_id = ?",
                new String[]{String.valueOf(category.getCategory_id()),String.valueOf(category.getUser_id())}
        );

        if (cursor != null && cursor.getCount() > 0) {
            Toast.makeText(this, "Không thể xóa: Danh mục đang được sử dụng trong Budgets", Toast.LENGTH_SHORT).show();
            cursor.close();
        } else {
            int result = db.delete("Categories", "category_id = ?", new String[]{String.valueOf(category.getCategory_id())});
            if (result > 0) {
                Toast.makeText(this, "Danh mục đã được xóa", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Không tìm thấy danh mục để xóa", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void updateCategory(Category category) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", category.getName());
        int t = -1;
        if (category.isType())
            t = 1;
        else
            t = 0;
        contentValues.put("type", t);
        int result = db.update("Categories", contentValues, "category_id = ? AND user_id = ?", new String[]{String.valueOf(category.getCategory_id()),String.valueOf(category.getUser_id())});
        if (result > 0) {
            Toast.makeText(this, "Danh mục đã được cập nhật", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Không tìm thấy danh mục để cập nhật", Toast.LENGTH_SHORT).show();
        }
    }
    public ArrayList<Category> getAll(int id){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT category_id, name, type FROM Categories WHERE user_id = ?", new String[]{String.valueOf(id)});
        ArrayList<Category> ds = new ArrayList<>();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int ma = cursor.getInt(0);
                String ten = cursor.getString(1);
                boolean loai = false;
                if (cursor.getInt(2) == 1)
                    loai = true;
                Category category = new Category(ma, ten, loai,id);
                ds.add(category);
            }
            cursor.close();
        }
        return ds;
    }
}