package vn.edu.stu.doan_giuaky_android.adapter;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.R;
import vn.edu.stu.doan_giuaky_android.model.Transaction;

public class GiaoDichAdapter extends BaseAdapter {

    Activity context;
    DBHelper dbHelper = new DBHelper(context);
    ArrayList<Transaction> ds;

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.item_giaodich, null);

        TextView tvMoTa = row.findViewById(R.id.tvMoTa);
        TextView tvDM = row.findViewById(R.id.tvDM);
        TextView tvKieu = row.findViewById(R.id.tvKieu);
        TextView tvTien = row.findViewById(R.id.tvTien);

        Transaction transaction = ds.get(i);
        tvMoTa.setText(transaction.getDescription());
        Cursor cursorDM = dbHelper.getReadableDatabase().rawQuery("SELECT type FROM Categories WHERE category_id = ? AND user_id = ?", new String[]{String.valueOf(transaction.getCategory_id()),String.valueOf(transaction.getUser_id())});
        int type = -1;
        while (cursorDM.moveToNext()) {
            type = cursorDM.getInt(0);
        }
        if (type == 1){
            tvKieu.setText("+");
        } else if (type == 0) {
            tvKieu.setText("-");
        }else
            Toast.makeText(context, "Lỗi!",Toast.LENGTH_LONG);
        return row;
    }
}

