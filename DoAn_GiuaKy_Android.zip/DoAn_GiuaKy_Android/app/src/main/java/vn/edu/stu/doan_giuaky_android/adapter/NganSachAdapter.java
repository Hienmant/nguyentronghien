package vn.edu.stu.doan_giuaky_android.adapter;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import vn.edu.stu.doan_giuaky_android.Database.DBHelper;
import vn.edu.stu.doan_giuaky_android.R;
import vn.edu.stu.doan_giuaky_android.model.Budget;
import vn.edu.stu.doan_giuaky_android.model.Transaction;
import vn.edu.stu.doan_giuaky_android.util.FormatUtil;

public class NganSachAdapter extends BaseAdapter {

    Activity context;
    DBHelper dbHelper = new DBHelper(context);
    ArrayList<Budget> ds;

    public NganSachAdapter(Activity context, ArrayList<Budget> ds) {
        this.context = context;
        this.ds = ds;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.item_ngansach, null);

        TextView tenNS = row.findViewById(R.id.tvTenNS);
        TextView tienChi = row.findViewById(R.id.tvChi);
        TextView tienNS = row.findViewById(R.id.tvNS);
        TextView ngaythangstart = row.findViewById(R.id.tvNgayThangStart);
        TextView ngaythangend = row.findViewById(R.id.tvNgayThangEnd);
        TextView namstart = row.findViewById(R.id.tvNamStart);
        TextView namend = row.findViewById(R.id.tvNamEnd);

        Budget budget = ds.get(position);
        Cursor cursorSum = null;
        Cursor cursorDM = null;
        try {
            cursorSum = dbHelper.getReadableDatabase().rawQuery("SELECT SUM(amount) FROM Transactions WHERE category_id = ? AND user_id = ? AND date < ?", new String[]{String.valueOf(budget.getCategory_id()), String.valueOf(budget.getUser_id()), FormatUtil.formatDateTime(budget.getEnd_date())});
            cursorDM = dbHelper.getReadableDatabase().rawQuery("SELECT name FROM Categories WHERE category_id = ? AND user_id = ?", new String[]{String.valueOf(budget.getCategory_id()), String.valueOf(budget.getUser_id())});
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (cursorSum != null) {
                cursorSum.close();
            }
            if (cursorDM != null)
                cursorDM.close();
        }
        int tongChiTieu = cursorSum.getInt(0);
        String ten = cursorDM.getString(0);
        tenNS.setText(ten);
        tienChi.setText(String.valueOf(tongChiTieu));
        tienNS.setText(String.valueOf(budget.getAmount()));
        ngaythangstart.setText(FormatUtil.formatDayMonth(budget.getStart_date()));
        ngaythangend.setText(FormatUtil.formatDayMonth(budget.getEnd_date()));
        namstart.setText(FormatUtil.formatYear(budget.getStart_date()));
        namend.setText(FormatUtil.formatYear(budget.getEnd_date()));
        return row;
    }
}
